package bill;

/**
 * @author nguyen
 * @create_date 20/07/2022
 */
public enum BillType {
  BUYING, SELLING
}