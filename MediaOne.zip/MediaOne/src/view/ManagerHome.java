/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import Controller.CustomerController;
import view.employeeform.EmployeeForm;
import view.bookform.BookFormEdit;
import view.bookform.BookForm;
import Controller.EmployeeController;
import view.clock.ClockThread;
import Controller.ProductController;
import Product.Book;
import Product.DiscMovie;
import Product.DiscMusic;
import java.awt.HeadlessException;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import person.Customer;
import person.Employee;
import view.bill.BuyBill;
import view.bill.OrderBill;
import view.customerform.CustomerForm;
import view.discMovieForm.DiscMovieForm;
import view.discMovieForm.DiscMovieFormEdit;
import view.discmusicform.DiscMusicForm;
import view.discmusicform.DiscMusicFormEdit;
import view.employeeform.EmployeeFormEdit;
import view.finance.FinanceForm;

/**
 *
 * @author Admin
 */
public class ManagerHome extends javax.swing.JFrame {
    Employee employee;
    EmployeeController employeeController;
    ProductController productController;
    CustomerController customerController;
    /**
     * Creates new form EmployeeHome
     */
    public ManagerHome() {
        initComponents();
        
    }
    public ManagerHome(Employee employee)  {
        this.employee=employee;
        productController= new ProductController(employee);
        employeeController= new EmployeeController(employee);
        initComponents();
        jLabel6.setText("UserName:"+employee.getAccount().getUserName());
        
        ClockThread th= new ClockThread(timeJLabel);
        th.start();
        DefaultTableModel defaultTableModel;
     defaultTableModel= new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }         
        } ; 
     listBookTable.setModel(defaultTableModel);
        
        defaultTableModel.addColumn("ID");
        defaultTableModel.addColumn("Code");
        defaultTableModel.addColumn("Name");
        defaultTableModel.addColumn("PurcharPrice");
        defaultTableModel.addColumn("SalePrice");
        defaultTableModel.addColumn("Remaining");
        defaultTableModel.addColumn("AddDate");
        defaultTableModel.addColumn("UpdateDate");
        defaultTableModel.addColumn("IdUpdater");
        defaultTableModel.addColumn("ProductPlacement");
        defaultTableModel.addColumn("Category");
        defaultTableModel.addColumn("Publisher");
        defaultTableModel.addColumn("Author");
        
        List<Book> books = productController.getListBook();
        for(Book book : books){
        defaultTableModel.addRow(new Object[]{book.getId(),book.getCode(),book.getName(),book.getPurchasePrice(),book.getSalePrice(),book.getRemaining(),formatter.format(book.getAddDate()),formatter.format(book.getUpdateDate()),book.getUpdater().getId(),
            book.getProductPlacement(),book.getCategory(),book.getPublisher(),book.getAuthor()  });
        }
        
        DefaultTableModel defaultTableMode2;
     defaultTableMode2= new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }         
        } ; 
     listDiscMusicTable1.setModel(defaultTableMode2);
        
        defaultTableMode2.addColumn("ID");
        defaultTableMode2.addColumn("Code");
        defaultTableMode2.addColumn("Name");
        defaultTableMode2.addColumn("PurcharPrice");
        defaultTableMode2.addColumn("SalePrice");
        defaultTableMode2.addColumn("Remaining");
        defaultTableMode2.addColumn("AddDate");
        defaultTableMode2.addColumn("UpdateDate");
        defaultTableMode2.addColumn("IdUpdater");
        defaultTableMode2.addColumn("ProductPlacement");
        defaultTableMode2.addColumn("Genre");
        defaultTableMode2.addColumn("Singer");

        List<DiscMusic> listDiscMusics = productController.getListDiscMusic();
         for(DiscMusic discMusic: listDiscMusics){
        defaultTableMode2.addRow(new Object[]{discMusic.getId(),discMusic.getCode(),discMusic.getName(),discMusic.getPurchasePrice(),discMusic.getSalePrice(),discMusic.getRemaining(),formatter.format(discMusic.getAddDate()),formatter.format(discMusic.getUpdateDate()),discMusic.getUpdater().getId(),
            discMusic.getProductPlacement(),discMusic.getGenre(),discMusic.getSinger()  });
        }  
        
         DefaultTableModel defaultTableModel3;
     defaultTableModel3= new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }         
        } ; 
     listDiscMovieJTable.setModel(defaultTableModel3);
        
        defaultTableModel3.addColumn("ID");
        defaultTableModel3.addColumn("Name");
        defaultTableModel3.addColumn("PurcharPrice");
        defaultTableModel3.addColumn("SalePrice");
        defaultTableModel3.addColumn("Remaining");
        defaultTableModel3.addColumn("AddDate");
        defaultTableModel3.addColumn("UpdateDate");
        defaultTableModel3.addColumn("IdUpdater");
        defaultTableModel3.addColumn("ProductPlacement");
        defaultTableModel3.addColumn("Genre");
        defaultTableModel3.addColumn("Length");
        defaultTableModel3.addColumn("year");
        defaultTableModel3.addColumn("actor");
        defaultTableModel3.addColumn("director");
        
        
          List<DiscMovie> discMovies= productController.getListDiscMovie();
          for(DiscMovie discMovie : discMovies){
        defaultTableModel3.addRow(new Object[]{discMovie.getId(),discMovie.getCode(),discMovie.getName(),discMovie.getPurchasePrice(),discMovie.getSalePrice(),discMovie.getRemaining(),formatter.format(discMovie.getAddDate()),formatter.format(discMovie.getUpdateDate()),discMovie.getUpdater().getId(),
            discMovie.getProductPlacement(),discMovie.getGenre(),discMovie.getLength(),discMovie.getYear(),discMovie.getActor(),discMovie.getDirector() });
        }
         
        DefaultTableModel defaultTableModel4;
        defaultTableModel4= new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        } ;
        listEmployeeJTable.setModel(defaultTableModel4);

        defaultTableModel4.addColumn("ID");
        defaultTableModel4.addColumn("Name");
        defaultTableModel4.addColumn("Phone");
        defaultTableModel4.addColumn("Born");
        defaultTableModel4.addColumn("Salary");
        defaultTableModel4.addColumn("Role");
        defaultTableModel4.addColumn("UserName");
        defaultTableModel4.addColumn("PassWord");
        

        List<Employee> employees= employeeController.getListEmployee();
        for(Employee employee1 : employees){
            defaultTableModel4.addRow(new Object[]{employee1.getId(),employee1.getName(),employee1.getPhone(),employee1.getBorn(),employee1.getSalary(),employee1.getAccount().getRole(),
                employee1.getAccount().getUserName(),employee1.getAccount().getPassword()  });
        }
        
        
        
        customerController= new CustomerController(employee);
        DefaultTableModel defaultTableModel5;
        defaultTableModel5 = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        } ;
        
        
        customerJTable1.setModel(defaultTableModel5);
       
        defaultTableModel5.addColumn("ID");
        defaultTableModel5.addColumn("Name");
        defaultTableModel5.addColumn("Born");
        defaultTableModel5.addColumn("Phone");
        defaultTableModel5.addColumn("Point");
          List<Customer> customers= customerController.getListCustomer();
          for(Customer customer: customers){
           defaultTableModel5.addRow(new Object[]{customer.getId(),customer.getName(),customer.getBorn(),customer.getPhone(),customer.getPoint() });
        
          }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
 //SimpleDateFormat  formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
 SimpleDateFormat  formatter = new SimpleDateFormat("yyyy-MM-dd");


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        timeJLabel = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        homeJTablePane = new javax.swing.JTabbedPane();
        bookJPanel = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jButton10 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        codeJTextField = new javax.swing.JTextField();
        findJButton = new javax.swing.JButton();
        bookJComboBox2 = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        listBookTable = new javax.swing.JTable();
        discMusicjPanel = new javax.swing.JPanel();
        discMusicJpanel = new javax.swing.JPanel();
        dircMusicjScrollPane3 = new javax.swing.JScrollPane();
        listDiscMusicTable1 = new javax.swing.JTable();
        jPanel6 = new javax.swing.JPanel();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        codeDiscMusicJTextField2 = new javax.swing.JTextField();
        findJButton2 = new javax.swing.JButton();
        discMusicJcombobox = new javax.swing.JComboBox<>();
        discMovieJPanel3 = new javax.swing.JPanel();
        discMovieJPanel = new javax.swing.JPanel();
        discMoviejScrollPane4 = new javax.swing.JScrollPane();
        listDiscMovieJTable = new javax.swing.JTable();
        jPanel7 = new javax.swing.JPanel();
        jButton15 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        codediscMovieJTextField3 = new javax.swing.JTextField();
        findJButton3 = new javax.swing.JButton();
        discMovieJcombobox1 = new javax.swing.JComboBox<>();
        customerjPanel = new javax.swing.JPanel();
        jButton7 = new javax.swing.JButton();
        phonejTextField3 = new javax.swing.JTextField();
        jComboBox2 = new javax.swing.JComboBox<>();
        jButton8 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        customerJTable1 = new javax.swing.JTable();
        employeeJPanel = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        userNameSearchJTextField1 = new javax.swing.JTextField();
        findJButton1 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        listEmployeeJTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Nhân viên:");

        timeJLabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        timeJLabel.setForeground(new java.awt.Color(255, 255, 255));
        timeJLabel.setText("Time:");

        jButton1.setBackground(new java.awt.Color(30, 39, 73));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Báo cáo tài chính");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(30, 39, 73));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Hóa đơn nhập hàng mới");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-slack-50.png"))); // NOI18N

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 255, 255));
        jLabel4.setText("ONEMEDIA");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jLabel4)))
                .addGap(38, 38, 38)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(242, 242, 242)
                .addComponent(jButton1)
                .addGap(26, 26, 26)
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 400, Short.MAX_VALUE)
                .addComponent(timeJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(205, 205, 205))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(7, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(24, 24, 24))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(timeJLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1678, -1));

        homeJTablePane.setBackground(new java.awt.Color(51, 51, 51));
        homeJTablePane.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        homeJTablePane.setForeground(new java.awt.Color(255, 255, 255));
        homeJTablePane.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        homeJTablePane.setOpaque(true);
        homeJTablePane.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                homeJTablePaneMouseClicked(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(34, 34, 34));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));

        jButton10.setBackground(new java.awt.Color(100, 119, 160));
        jButton10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton10.setForeground(new java.awt.Color(255, 255, 255));
        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/plus-8-16.png"))); // NOI18N
        jButton10.setText("Thêm mới");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton9.setBackground(new java.awt.Color(56, 80, 126));
        jButton9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton9.setForeground(new java.awt.Color(255, 255, 255));
        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-edit-20.png"))); // NOI18N
        jButton9.setText("Chỉnh sửa");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        codeJTextField.setBackground(new java.awt.Color(255, 255, 255));
        codeJTextField.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        codeJTextField.setForeground(new java.awt.Color(0, 0, 0));
        codeJTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                codeJTextFieldActionPerformed(evt);
            }
        });

        findJButton.setBackground(new java.awt.Color(23, 44, 84));
        findJButton.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        findJButton.setForeground(new java.awt.Color(255, 255, 255));
        findJButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/search-3-16.png"))); // NOI18N
        findJButton.setText("Tìm kiếm");
        findJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findJButtonActionPerformed(evt);
            }
        });

        bookJComboBox2.setBackground(new java.awt.Color(255, 255, 255));
        bookJComboBox2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        bookJComboBox2.setForeground(new java.awt.Color(0, 0, 0));
        bookJComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mã sản phẩm", "Tên sản phẩm" }));

        listBookTable.setBackground(new java.awt.Color(34, 34, 34));
        listBookTable.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        listBookTable.setForeground(new java.awt.Color(255, 255, 255));
        listBookTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(listBookTable);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(173, 173, 173)
                .addComponent(bookJComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(codeJTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(59, 59, 59)
                .addComponent(findJButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton10)
                .addContainerGap(730, Short.MAX_VALUE))
            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bookJComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(codeJTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(findJButton)
                    .addComponent(jButton9)
                    .addComponent(jButton10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 563, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout bookJPanelLayout = new javax.swing.GroupLayout(bookJPanel);
        bookJPanel.setLayout(bookJPanelLayout);
        bookJPanelLayout.setHorizontalGroup(
            bookJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        bookJPanelLayout.setVerticalGroup(
            bookJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bookJPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        homeJTablePane.addTab("Sách", bookJPanel);

        discMusicJpanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        dircMusicjScrollPane3.setForeground(new java.awt.Color(255, 255, 255));

        listDiscMusicTable1.setBackground(new java.awt.Color(34, 34, 34));
        listDiscMusicTable1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        listDiscMusicTable1.setForeground(new java.awt.Color(255, 255, 255));
        listDiscMusicTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        dircMusicjScrollPane3.setViewportView(listDiscMusicTable1);

        discMusicJpanel.add(dircMusicjScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 1680, 560));

        jPanel6.setBackground(new java.awt.Color(34, 34, 34));

        jButton13.setBackground(new java.awt.Color(100, 119, 160));
        jButton13.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton13.setForeground(new java.awt.Color(255, 255, 255));
        jButton13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/plus-8-16.png"))); // NOI18N
        jButton13.setText("Thêm mới");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        jButton14.setBackground(new java.awt.Color(56, 80, 126));
        jButton14.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton14.setForeground(new java.awt.Color(255, 255, 255));
        jButton14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-edit-20.png"))); // NOI18N
        jButton14.setText("Chỉnh sửa");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        codeDiscMusicJTextField2.setBackground(new java.awt.Color(255, 255, 255));
        codeDiscMusicJTextField2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        codeDiscMusicJTextField2.setForeground(new java.awt.Color(0, 0, 0));
        codeDiscMusicJTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                codeDiscMusicJTextField2ActionPerformed(evt);
            }
        });

        findJButton2.setBackground(new java.awt.Color(23, 44, 84));
        findJButton2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        findJButton2.setForeground(new java.awt.Color(255, 255, 255));
        findJButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/search-3-16.png"))); // NOI18N
        findJButton2.setText("Tìm kiếm");
        findJButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findJButton2ActionPerformed(evt);
            }
        });

        discMusicJcombobox.setBackground(new java.awt.Color(255, 255, 255));
        discMusicJcombobox.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        discMusicJcombobox.setForeground(new java.awt.Color(0, 0, 0));
        discMusicJcombobox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mã sản phẩm", "Tên sản phẩm" }));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(189, 189, 189)
                .addComponent(discMusicJcombobox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(codeDiscMusicJTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(findJButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton13)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton14)
                    .addComponent(jButton13)
                    .addComponent(findJButton2)
                    .addComponent(codeDiscMusicJTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(discMusicJcombobox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(36, Short.MAX_VALUE))
        );

        discMusicJpanel.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1807, -1));

        javax.swing.GroupLayout discMusicjPanelLayout = new javax.swing.GroupLayout(discMusicjPanel);
        discMusicjPanel.setLayout(discMusicjPanelLayout);
        discMusicjPanelLayout.setHorizontalGroup(
            discMusicjPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(discMusicJpanel, javax.swing.GroupLayout.PREFERRED_SIZE, 1692, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        discMusicjPanelLayout.setVerticalGroup(
            discMusicjPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(discMusicJpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        homeJTablePane.addTab("Đĩa nhạc", discMusicjPanel);

        discMovieJPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        listDiscMovieJTable.setBackground(new java.awt.Color(34, 34, 34));
        listDiscMovieJTable.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        listDiscMovieJTable.setForeground(new java.awt.Color(255, 255, 255));
        listDiscMovieJTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        discMoviejScrollPane4.setViewportView(listDiscMovieJTable);

        discMovieJPanel.add(discMoviejScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 62, 1679, 550));

        jPanel7.setBackground(new java.awt.Color(34, 34, 34));

        jButton15.setBackground(new java.awt.Color(100, 119, 160));
        jButton15.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton15.setForeground(new java.awt.Color(255, 255, 255));
        jButton15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/plus-8-16.png"))); // NOI18N
        jButton15.setText("Thêm mới");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        jButton16.setBackground(new java.awt.Color(56, 80, 126));
        jButton16.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton16.setForeground(new java.awt.Color(255, 255, 255));
        jButton16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-edit-20.png"))); // NOI18N
        jButton16.setText("Chỉnh sửa");
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });

        codediscMovieJTextField3.setBackground(new java.awt.Color(255, 255, 255));
        codediscMovieJTextField3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        codediscMovieJTextField3.setForeground(new java.awt.Color(255, 255, 255));
        codediscMovieJTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                codediscMovieJTextField3ActionPerformed(evt);
            }
        });

        findJButton3.setBackground(new java.awt.Color(23, 44, 84));
        findJButton3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        findJButton3.setForeground(new java.awt.Color(255, 255, 255));
        findJButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/search-3-16.png"))); // NOI18N
        findJButton3.setText("Tìm kiếm");
        findJButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findJButton3ActionPerformed(evt);
            }
        });

        discMovieJcombobox1.setBackground(new java.awt.Color(255, 255, 255));
        discMovieJcombobox1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        discMovieJcombobox1.setForeground(new java.awt.Color(0, 0, 0));
        discMovieJcombobox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mã sản phẩm", "Tên sản phẩm" }));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(170, 170, 170)
                .addComponent(discMovieJcombobox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(codediscMovieJTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(findJButton3)
                .addGap(12, 12, 12)
                .addComponent(jButton16)
                .addGap(12, 12, 12)
                .addComponent(jButton15))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(discMovieJcombobox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(codediscMovieJTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(findJButton3)
                    .addComponent(jButton16)
                    .addComponent(jButton15)))
        );

        discMovieJPanel.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1822, 60));

        javax.swing.GroupLayout discMovieJPanel3Layout = new javax.swing.GroupLayout(discMovieJPanel3);
        discMovieJPanel3.setLayout(discMovieJPanel3Layout);
        discMovieJPanel3Layout.setHorizontalGroup(
            discMovieJPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1822, Short.MAX_VALUE)
            .addGroup(discMovieJPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(discMovieJPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        discMovieJPanel3Layout.setVerticalGroup(
            discMovieJPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 645, Short.MAX_VALUE)
            .addGroup(discMovieJPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(discMovieJPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        homeJTablePane.addTab("Đĩa phim", discMovieJPanel3);

        customerjPanel.setBackground(new java.awt.Color(34, 34, 34));

        jButton7.setBackground(new java.awt.Color(56, 80, 126));
        jButton7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/plus-8-16.png"))); // NOI18N
        jButton7.setText("Tạo mới khách hàng");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        phonejTextField3.setBackground(new java.awt.Color(255, 255, 255));
        phonejTextField3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        phonejTextField3.setForeground(new java.awt.Color(0, 0, 0));

        jComboBox2.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jComboBox2.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Số điện thoại", "Họ và tên" }));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        jButton8.setBackground(new java.awt.Color(23, 44, 84));
        jButton8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/search-3-16.png"))); // NOI18N
        jButton8.setText("Tra thông tin");

        customerJTable1.setBackground(new java.awt.Color(34, 34, 34));
        customerJTable1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        customerJTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(customerJTable1);

        javax.swing.GroupLayout customerjPanelLayout = new javax.swing.GroupLayout(customerjPanel);
        customerjPanel.setLayout(customerjPanelLayout);
        customerjPanelLayout.setHorizontalGroup(
            customerjPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(customerjPanelLayout.createSequentialGroup()
                .addGap(162, 162, 162)
                .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(phonejTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(jButton8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton7)
                .addContainerGap(774, Short.MAX_VALUE))
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        customerjPanelLayout.setVerticalGroup(
            customerjPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(customerjPanelLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(customerjPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton7)
                    .addComponent(jButton8)
                    .addComponent(phonejTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 554, Short.MAX_VALUE)
                .addContainerGap())
        );

        homeJTablePane.addTab("Quản lý khách hàng ", customerjPanel);

        employeeJPanel.setBackground(new java.awt.Color(34, 34, 34));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("UserName :");

        userNameSearchJTextField1.setBackground(new java.awt.Color(255, 255, 255));
        userNameSearchJTextField1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        userNameSearchJTextField1.setForeground(new java.awt.Color(0, 0, 0));
        userNameSearchJTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userNameSearchJTextField1ActionPerformed(evt);
            }
        });

        findJButton1.setBackground(new java.awt.Color(23, 44, 84));
        findJButton1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        findJButton1.setForeground(new java.awt.Color(255, 255, 255));
        findJButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/search-3-16.png"))); // NOI18N
        findJButton1.setText("Tìm kiếm");
        findJButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findJButton1ActionPerformed(evt);
            }
        });

        jButton11.setBackground(new java.awt.Color(56, 80, 126));
        jButton11.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton11.setForeground(new java.awt.Color(255, 255, 255));
        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-edit-20.png"))); // NOI18N
        jButton11.setText("Chỉnh sửa");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jButton12.setBackground(new java.awt.Color(100, 119, 160));
        jButton12.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton12.setForeground(new java.awt.Color(255, 255, 255));
        jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/plus-8-16.png"))); // NOI18N
        jButton12.setText("Thêm mới");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        listEmployeeJTable.setBackground(new java.awt.Color(34, 34, 34));
        listEmployeeJTable.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        listEmployeeJTable.setForeground(new java.awt.Color(255, 255, 255));
        listEmployeeJTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane3.setViewportView(listEmployeeJTable);

        javax.swing.GroupLayout employeeJPanelLayout = new javax.swing.GroupLayout(employeeJPanel);
        employeeJPanel.setLayout(employeeJPanelLayout);
        employeeJPanelLayout.setHorizontalGroup(
            employeeJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(employeeJPanelLayout.createSequentialGroup()
                .addGap(234, 234, 234)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(userNameSearchJTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47)
                .addComponent(findJButton1)
                .addGap(18, 18, 18)
                .addComponent(jButton11)
                .addGap(18, 18, 18)
                .addComponent(jButton12)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(employeeJPanelLayout.createSequentialGroup()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 1677, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        employeeJPanelLayout.setVerticalGroup(
            employeeJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(employeeJPanelLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(employeeJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton12)
                    .addComponent(jButton11)
                    .addComponent(findJButton1)
                    .addComponent(userNameSearchJTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 558, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        homeJTablePane.addTab("Quản lý nhân viên", employeeJPanel);

        getContentPane().add(homeJTablePane, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 1680, 680));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        new FinanceForm(employee).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void homeJTablePaneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeJTablePaneMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_homeJTablePaneMouseClicked

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        customerController= new CustomerController(employee);
        if (phonejTextField3.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Vui lòng nhập số điện thoại khách hàng cần thêm");
        }
        else{
            if (customerController.getCustomerByPhone(phonejTextField3.getText())!= null ){
                JOptionPane.showMessageDialog(null, "Mã sản phẩm đã tồn tại \n Vui  lòng nhập mã sản phẩm khác hoặc lựa chọn chức năng chỉnh sửa");
            }
            else{
                new CustomerForm(phonejTextField3.getText(),employee).setVisible(true);
                this.setVisible(false);
            }
        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        // TODO add your handling code here:

        new EmployeeForm(employee).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
        employeeController = new EmployeeController(employee);
        String userName= userNameSearchJTextField1.getText();

        if ( employeeController.getEmployeeByUserName(userName)!= null ){
            new EmployeeFormEdit(employeeController.getEmployeeByUserName(userName), employee).setVisible(true);
            this.setVisible(false);
        }
        else{
            JOptionPane.showMessageDialog(null, "Mã nhân viên chưa tồn tại");
        }
    }//GEN-LAST:event_jButton11ActionPerformed

    private void findJButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findJButton1ActionPerformed
        // TODO add your handling code here:
        employeeController = new EmployeeController(employee);
        DefaultTableModel defaultTableModel;
        defaultTableModel= new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        } ;
        listEmployeeJTable.setModel(defaultTableModel);

        defaultTableModel.addColumn("ID");
        defaultTableModel.addColumn("Name");
        defaultTableModel.addColumn("Phone");
        defaultTableModel.addColumn("Born");
        defaultTableModel.addColumn("Salary");
        defaultTableModel.addColumn("Role");
        defaultTableModel.addColumn("UserName");
        defaultTableModel.addColumn("PassWord");

        try {
            employee = employeeController.getEmployeeByUserName(userNameSearchJTextField1.getText());
            defaultTableModel.addRow(new Object[]{employee.getId(),employee.getName(),employee.getPhone(),employee.getBorn(),employee.getSalary(),employee.getAccount().getRole(),
                employee.getAccount().getUserName(),employee.getAccount().getPassword()  });

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Nhap lai ma nhan vien");
        }
    }//GEN-LAST:event_findJButton1ActionPerformed

    private void userNameSearchJTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userNameSearchJTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_userNameSearchJTextField1ActionPerformed

    private void findJButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findJButton3ActionPerformed
        // TODO add your handling code here:
        productController= new ProductController(employee);
        DefaultTableModel defaultTableModel;
        defaultTableModel= new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        } ;
        listDiscMovieJTable.setModel(defaultTableModel);

        defaultTableModel.addColumn("ID");
        defaultTableModel.addColumn("Code");
        defaultTableModel.addColumn("Name");
        defaultTableModel.addColumn("PurcharPrice");
        defaultTableModel.addColumn("SalePrice");
        defaultTableModel.addColumn("Remaining");
        defaultTableModel.addColumn("AddDate");
        defaultTableModel.addColumn("UpdateDate");
        defaultTableModel.addColumn("IdUpdater");
        defaultTableModel.addColumn("ProductPlacement");
        defaultTableModel.addColumn("Genre");
        defaultTableModel.addColumn("Length");
        defaultTableModel.addColumn("year");
        defaultTableModel.addColumn("actor");
        defaultTableModel.addColumn("director");

        if ( discMovieJcombobox1.getSelectedItem().equals("Tên sản phẩm") ){
            List<DiscMovie> discMovies= productController.getDiscMovieByName(codediscMovieJTextField3.getText());
            for(DiscMovie discMovie : discMovies){
                defaultTableModel.addRow(new Object[]{discMovie.getId(),discMovie.getCode(),discMovie.getName(),discMovie.getPurchasePrice(),discMovie.getSalePrice(),discMovie.getRemaining(),formatter.format(discMovie.getAddDate()),formatter.format(discMovie.getUpdateDate()),discMovie.getUpdater().getId(),
                    discMovie.getProductPlacement(),discMovie.getGenre(),discMovie.getLength(),discMovie.getYear(),discMovie.getActor(),discMovie.getDirector() });
        }
        }
        else{

            try {
                DiscMovie discMovie= productController.getDiscMovieByCode(codediscMovieJTextField3.getText());
                defaultTableModel.addRow(new Object[]{discMovie.getId(),discMovie.getCode(),discMovie.getName(),discMovie.getPurchasePrice(),discMovie.getSalePrice(),discMovie.getRemaining(),formatter.format(discMovie.getAddDate()),formatter.format(discMovie.getUpdateDate()),discMovie.getUpdater().getId(),
                    discMovie.getProductPlacement(),discMovie.getGenre(),discMovie.getLength(),discMovie.getYear(),discMovie.getActor(),discMovie.getDirector() });
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Nhập lại mã sản phẩm: ");
        }

        }
    }//GEN-LAST:event_findJButton3ActionPerformed

    private void codediscMovieJTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_codediscMovieJTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_codediscMovieJTextField3ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        // TODO add your handling code here:
        if ( discMovieJcombobox1.getSelectedItem().equals("Tên sản phẩm") ){
            JOptionPane.showMessageDialog(null, "Vui lòng chọn mã sản phẩm để chỉnh sửa");
        }
        else{
            productController= new ProductController(employee);
            String code= codediscMovieJTextField3.getText();

            if ( productController.getDiscMovieByCode(code)!= null ){
                new DiscMovieFormEdit( productController.getDiscMovieByCode(code),employee).setVisible(true);
                this.setVisible(false);
            }
            else{
                JOptionPane.showMessageDialog(null, "Mã sản phẩm chưa tồn tại");
            }
        }
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        // TODO add your handling code here:
        if ( String.valueOf(discMovieJcombobox1.getSelectedItem()).equals("Tên sản phẩm") ){
            JOptionPane.showMessageDialog(null, "Vui lòng chọn mã sản phẩm để thêm mới");
        }
        else{
            productController = new ProductController(employee);
            if (codediscMovieJTextField3.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Vui lòng nhập mã sản phẩm bạn muốn thêm");
            }
            else{
                if (productController.getProductByCode(codeDiscMusicJTextField2.getText())!= null ){
                    JOptionPane.showMessageDialog(null, "Mã sản phẩm đã tồn tại \n Vui  lòng nhập mã sản phẩm khác hoặc lựa chọn chức năng chỉnh sửa");
                }
                else{
                    new DiscMovieForm(codediscMovieJTextField3.getText(),employee).setVisible(true);
                    this.setVisible(false);
                }
            }
        }
    }//GEN-LAST:event_jButton15ActionPerformed

    private void findJButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findJButton2ActionPerformed
        // TODO add your handling code here:
        productController= new ProductController(employee);
        DefaultTableModel defaultTableModel;
        defaultTableModel= new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        } ;
        listDiscMusicTable1.setModel(defaultTableModel);

        defaultTableModel.addColumn("ID");
        defaultTableModel.addColumn("Code");
        defaultTableModel.addColumn("Name");
        defaultTableModel.addColumn("PurcharPrice");
        defaultTableModel.addColumn("SalePrice");
        defaultTableModel.addColumn("Remaining");
        defaultTableModel.addColumn("AddDate");
        defaultTableModel.addColumn("UpdateDate");
        defaultTableModel.addColumn("IdUpdater");
        defaultTableModel.addColumn("ProductPlacement");
        defaultTableModel.addColumn("Genre");
        defaultTableModel.addColumn("Singer");

        if ( discMusicJcombobox.getSelectedItem().equals("Tên sản phẩm") ){
            List<DiscMusic> listDiscMusics= productController.getDiscMusicsByName(codeDiscMusicJTextField2.getText());
            for(DiscMusic discMusic : listDiscMusics){

                defaultTableModel.addRow(new Object[]{discMusic.getId(),discMusic.getCode(),discMusic.getName(),discMusic.getPurchasePrice(),discMusic.getSalePrice(),discMusic.getRemaining(),formatter.format(discMusic.getAddDate()),formatter.format(discMusic.getUpdateDate()),discMusic.getUpdater().getId(),
                    discMusic.getProductPlacement(),discMusic.getGenre(),discMusic.getSinger()  });
        }
        }
        else{

            try {
                DiscMusic discMusic = productController.getDiscMusicByCode(codeDiscMusicJTextField2.getText());
                defaultTableModel.addRow(new Object[]{discMusic.getId(),discMusic.getCode(),discMusic.getName(),discMusic.getPurchasePrice(),discMusic.getSalePrice(),discMusic.getRemaining(),formatter.format(discMusic.getAddDate()),formatter.format(discMusic.getUpdateDate()),discMusic.getUpdater().getId(),
                    discMusic.getProductPlacement(),discMusic.getGenre(),discMusic.getSinger()  });
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Nhập lại mã sản phẩm: ");
        }

        }
    }//GEN-LAST:event_findJButton2ActionPerformed

    private void codeDiscMusicJTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_codeDiscMusicJTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_codeDiscMusicJTextField2ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        // TODO add your handling code here:
        productController= new ProductController(employee);
        String code= codeDiscMusicJTextField2.getText();

        if ( discMusicJcombobox.getSelectedItem().equals("Tên sản phẩm") ){
            JOptionPane.showMessageDialog(null, "Vui lòng chọn mã sản phẩm để chỉnh sửa");
        }
        else{

            if ( productController.getDiscMusicByCode(code)!= null ){
                new DiscMusicFormEdit(productController.getDiscMusicByCode(code),employee).setVisible(true);
                this.setVisible(false);
            }
            else{
                JOptionPane.showMessageDialog(null, "Mã sản phẩm chưa tồn tại");
            }
        }
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        // TODO add your handling code here:
        if ( String.valueOf(discMusicJcombobox.getSelectedItem()).equals("Tên sản phẩm") ){
            JOptionPane.showMessageDialog(null, "Vui lòng chọn mã sản phẩm để thêm mới");
        }
        else{
            productController = new ProductController(employee);
            if (codeDiscMusicJTextField2.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Vui lòng nhập mã sản phẩm bạn muốn thêm");
            }
            else{
                if (productController.getProductByCode(codeDiscMusicJTextField2.getText())!= null ){
                    JOptionPane.showMessageDialog(null, "Mã sản phẩm đã tồn tại \n Vui  lòng nhập mã sản phẩm khác hoặc lựa chọn chức năng chỉnh sửa");
                }
                else{
                    new DiscMusicForm(codeDiscMusicJTextField2.getText(),employee).setVisible(true);
                    this.setVisible(false);
                }

            }
        }
    }//GEN-LAST:event_jButton13ActionPerformed

    private void findJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findJButtonActionPerformed
        // TODO add your handling code here:
        productController= new ProductController(employee);
        DefaultTableModel defaultTableModel;
        defaultTableModel= new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        } ;
        listBookTable.setModel(defaultTableModel);

        defaultTableModel.addColumn("ID");
        defaultTableModel.addColumn("Code");
        defaultTableModel.addColumn("Name");
        defaultTableModel.addColumn("PurcharPrice");
        defaultTableModel.addColumn("SalePrice");
        defaultTableModel.addColumn("Remaining");
        defaultTableModel.addColumn("AddDate");
        defaultTableModel.addColumn("UpdateDate");
        defaultTableModel.addColumn("IdUpdater");
        defaultTableModel.addColumn("ProductPlacement");
        defaultTableModel.addColumn("Category");
        defaultTableModel.addColumn("Publisher");
        defaultTableModel.addColumn("Author");

        if ( bookJComboBox2.getSelectedItem().equals("Tên sản phẩm") ){
            List<Book> books= productController.getBooksByName(codeJTextField.getText());
            for(Book book : books){
                defaultTableModel.addRow(new Object[]{book.getId(),book.getCode(),book.getName(),book.getPurchasePrice(),book.getSalePrice(),book.getRemaining(),formatter.format(book.getAddDate()),formatter.format(book.getUpdateDate()),book.getUpdater().getId(),
                    book.getProductPlacement(),book.getCategory(),book.getPublisher(),book.getAuthor()  });
        }
        }
        else{

            try {
                Book book= productController.getBookByCode(codeJTextField.getText());
                defaultTableModel.addRow(new Object[]{book.getId(),book.getCode(),book.getName(),book.getPurchasePrice(),book.getSalePrice(),book.getRemaining(),book.getAddDate(),book.getUpdateDate(),book.getUpdater().getId(),
                    book.getProductPlacement(),book.getCategory(),book.getPublisher(),book.getAuthor()  });
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Nhập lại mã sản phẩm: ");
        }

        }
    }//GEN-LAST:event_findJButtonActionPerformed

    private void codeJTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_codeJTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_codeJTextFieldActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
        if ( bookJComboBox2.getSelectedItem().equals("Tên sản phẩm") ){
            JOptionPane.showMessageDialog(null, "Vui lòng chọn mã sản phẩm để chỉnh sửa");
        }
        else{
            productController= new ProductController(employee);
            String code= codeJTextField.getText();

            if ( productController.getBookByCode(code)!= null ){
                new BookFormEdit(productController.getBookByCode(code),employee).setVisible(true);
                this.setVisible(false);
            }
            else{
                JOptionPane.showMessageDialog(null, "Mã sản phẩm chưa tồn tại");
            }
        }
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
        if ( String.valueOf(bookJComboBox2.getSelectedItem()).equals("Tên sản phẩm") ){
            JOptionPane.showMessageDialog(null, "Vui lòng chọn mã sản phẩm để thêm mới");
        }
        else{
            productController = new ProductController(employee);
            if (codeJTextField.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Vui lòng nhập mã sản phẩm bạn muốn thêm");
            }
            else{
                if (productController.getProductByCode(codeJTextField.getText())!= null ){
                    JOptionPane.showMessageDialog(null, "Mã sản phẩm đã tồn tại \n Vui  lòng nhập mã sản phẩm khác hoặc lựa chọn chức năng chỉnh sửa");
                }
                else{
                    new BookForm(codeJTextField.getText(),employee).setVisible(true);
                    this.setVisible(false);
                }
            }
        }
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        new BuyBill(employee).setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManagerHome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManagerHome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManagerHome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManagerHome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManagerHome().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> bookJComboBox2;
    private javax.swing.JPanel bookJPanel;
    private javax.swing.JTextField codeDiscMusicJTextField2;
    private javax.swing.JTextField codeJTextField;
    private javax.swing.JTextField codediscMovieJTextField3;
    private javax.swing.JTable customerJTable1;
    private javax.swing.JPanel customerjPanel;
    private javax.swing.JScrollPane dircMusicjScrollPane3;
    private javax.swing.JPanel discMovieJPanel;
    private javax.swing.JPanel discMovieJPanel3;
    private javax.swing.JComboBox<String> discMovieJcombobox1;
    private javax.swing.JScrollPane discMoviejScrollPane4;
    private javax.swing.JComboBox<String> discMusicJcombobox;
    private javax.swing.JPanel discMusicJpanel;
    private javax.swing.JPanel discMusicjPanel;
    private javax.swing.JPanel employeeJPanel;
    private javax.swing.JButton findJButton;
    private javax.swing.JButton findJButton1;
    private javax.swing.JButton findJButton2;
    private javax.swing.JButton findJButton3;
    private javax.swing.JTabbedPane homeJTablePane;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable listBookTable;
    private javax.swing.JTable listDiscMovieJTable;
    private javax.swing.JTable listDiscMusicTable1;
    private javax.swing.JTable listEmployeeJTable;
    private javax.swing.JTextField phonejTextField3;
    private javax.swing.JLabel timeJLabel;
    private javax.swing.JTextField userNameSearchJTextField1;
    // End of variables declaration//GEN-END:variables
}
