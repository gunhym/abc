/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package person;

/**
 *
 * @author Admin
 */
public class Manager extends Employee{

    public Manager(Account account, int salary, int id, String name, int born, String phone) {
        super(account, salary, id, name, born, phone);
    }

    public Manager() {
    }
    
}
